const mysql = require('mysql');

const pool  = mysql.createPool({
    connectionLimit: 10,
    host: "bv2rebwf6zzsv341.cbetxkdyhwsb.us-east-1.rds.amazonaws.com",
     user: "nwupoc0abiucs7jt",
     password: "ea1sbzi8aqmdhxzs",
     database: "yecfgxdv0h1eoy18"
});

module.exports = pool;